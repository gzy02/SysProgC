#include <stdio.h>
#include <string.h>
#include "string-count.h"

#define TODO()\
do{\
    extern int printf(char *, ...);\
    printf("Add your code here: file %s, line %d\n", __FILE__, __LINE__);\
}while(0)




int CountString(char* str) {
    // Exercise:
    // Add your code here:
    TODO();

}

